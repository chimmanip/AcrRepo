#!/usr/bin/env bash
# Exit on error
set -e

# Activate virtual environment if you have one
# source venv/bin/activate

# Run the Python script
python3 main.py